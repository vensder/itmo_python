__author__ = 'vensder'

def get_message():
	return "Hello World!"
	
def print_message():
	print('Hello Bro!')
